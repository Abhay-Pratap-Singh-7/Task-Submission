// DOM Elements
const wordInput = document.getElementById('word-input');
const searchBtn = document.getElementById('search-btn');
const historyList = document.getElementById('history-list');
const clearHistoryBtn = document.getElementById('clear-history');
const loading = document.getElementById('loading');
const initialState = document.getElementById('initial-state');
const resultContent = document.getElementById('result-content');
const resultWord = document.getElementById('result-word');
const fullResponse = document.getElementById('full-response');

// Global variables
const MAX_HISTORY_ITEMS = 5;
let searchHistory = JSON.parse(localStorage.getItem('searchHistory')) || [];

// Initialize the app
function init() {
    renderSearchHistory();
    
    // Event listeners
    searchBtn.addEventListener('click', handleSearch);
    wordInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });
    
    // Clear history button event listener
    clearHistoryBtn.addEventListener('click', clearSearchHistory);
    
    // Focus on input field on load
    wordInput.focus();
}

// Handle search
async function handleSearch() {
    const word = wordInput.value.trim().toLowerCase();
    
    if (!word) {
        alert('Please enter a word to search');
        return;
    }
    
    // Show loading state
    showLoadingState();
    
    try {
        const response = await getDictionaryDefinition(word);
        
        // Update UI with the results
        updateResultUI(word, response);
        
        // Update search history
        updateSearchHistory(word);
        
    } catch (error) {
        console.error('Error fetching definition:', error);
        hideLoadingState();
        alert('Failed to get definition. Please try again later.');
    }
}

// Function to get dictionary definition using OpenRouter API
async function getDictionaryDefinition(word) {
    // Note: In a production environment, API keys should not be exposed in client-side code
    // You should use a backend service to hide your API key
    const API_KEY = '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'; // Replace this with your actual API key
    const API_URL = 'https://openrouter.ai/api/v1/chat/completions';
    
    const prompt = `Define the word "${word}" in a detailed manner. Do not include headings like "Definition:" or "Examples:". Start directly with the definition and then provide some example sentences. Also include any synonyms or antonyms if relevant.`;
    
    const requestBody = {
        model: 'agentica-org/deepcoder-14b-preview:free',
        messages: [
            { role: 'user', content: prompt }
        ],
        max_tokens: 1000
    };
    
    const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${API_KEY}`,
            'HTTP-Referer': 'https://aidictionary.app', // Replace with your actual domain
            'X-Title': 'AI Dictionary'
        },
        body: JSON.stringify(requestBody)
    });
    
    if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`);
    }
    
    const data = await response.json();
    return data.choices[0].message.content;
}

// Format content for better readability
function formatContent(text) {
    if (!text) return '';
    
    // Replace newlines with <br> tags
    let formatted = text.replace(/\n/g, '<br>');
    
    // Format numbered lists
    formatted = formatted.replace(/(\d+\.)([^\n<]+)/g, '<p class="list-item"><span class="list-number">$1</span>$2</p>');
    
    // Format bullet points
    formatted = formatted.replace(/(-|\*)([^\n<]+)/g, '<p class="list-item"><span class="bullet">•</span>$2</p>');
    
    return formatted;
}

// Update UI with search results
function updateResultUI(word, response) {
    // Update the UI
    resultWord.textContent = word;
    
    // Format and insert the content as HTML
    fullResponse.innerHTML = formatContent(response);
    
    // Hide loading, show result
    hideLoadingState();
    initialState.classList.add('hidden');
    resultContent.classList.remove('hidden');
}

// Show loading state
function showLoadingState() {
    initialState.classList.add('hidden');
    resultContent.classList.add('hidden');
    loading.classList.remove('hidden');
}

// Hide loading state
function hideLoadingState() {
    loading.classList.add('hidden');
}

// Update search history
function updateSearchHistory(word) {
    // Remove existing entry of the same word (if any)
    searchHistory = searchHistory.filter(item => item.toLowerCase() !== word.toLowerCase());
    
    // Add the new word to the beginning of the array
    searchHistory.unshift(word);
    
    // Limit history items
    if (searchHistory.length > MAX_HISTORY_ITEMS) {
        searchHistory = searchHistory.slice(0, MAX_HISTORY_ITEMS);
    }
    
    // Save to local storage
    localStorage.setItem('searchHistory', JSON.stringify(searchHistory));
    
    // Update the UI
    renderSearchHistory();
}

// Clear search history
function clearSearchHistory() {
    searchHistory = [];
    localStorage.removeItem('searchHistory');
    renderSearchHistory();
}

// Render search history
function renderSearchHistory() {
    historyList.innerHTML = '';
    
    searchHistory.forEach(word => {
        const li = document.createElement('li');
        li.textContent = word;
        li.addEventListener('click', () => {
            wordInput.value = word;
            handleSearch();
        });
        
        historyList.appendChild(li);
    });
    
    // Show/hide the clear history button based on whether there's history
    clearHistoryBtn.style.display = searchHistory.length > 0 ? 'block' : 'none';
}

// Initialize the app when the DOM is loaded
document.addEventListener('DOMContentLoaded', init); 