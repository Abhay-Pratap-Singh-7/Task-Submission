# AiDic - AI Dictionary Application

AiDic is a web application that uses AI to provide definitions and examples for words. It features a clean, modern interface with a professional look, following the specified color theme.

## Features

- Search for word definitions using AI (powered by OpenRouter)
- Get detailed definitions and example sentences for words
- Search history saved in local storage
- Responsive design for desktop and mobile devices
- Professional UI with left panel for input and right panel for results

## Color Theme

- Primary Color: #FF0032
- White: #FFFFFF
- Light Gray: #F7F7F7

## Setup

1. Clone the repository
2. Open `script.js` and replace `'YOUR_OPENROUTER_API_KEY'` with your actual OpenRouter API key
3. Update the `'HTTP-Referer'` header in the API request to match your domain
4. Open `index.html` in a web browser or deploy to a web server

## API Configuration

This project uses OpenRouter API to access AI models for generating definitions. To use this application, you'll need to:

1. Sign up for an account at [OpenRouter](https://openrouter.ai/)
2. Get your API key from your account dashboard
3. Insert your API key in the `script.js` file

## Local Development

For local development, simply open the `index.html` file in your browser. The application uses vanilla HTML, CSS, and JavaScript, so there's no need for a build step.

## Deployment

You can deploy this application to any static web hosting service like:
- GitHub Pages
- Netlify
- Vercel
- Amazon S3
- Any standard web server

## Security Note

For production use, it's recommended to:
1. Use a backend service to proxy API requests and hide your API keys
2. Implement rate limiting to prevent API abuse
3. Add error handling for edge cases

## License

This project is available under the MIT License.

---

Created by [Your Name] 